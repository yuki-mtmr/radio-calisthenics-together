"""YouTube 自動投稿クライアント。

OAuth 認証（トークンキャッシュ + リトライ付きリフレッシュ + 新規認証フォールバック）、
動画アップロード、ライブ配信枠の作成・管理を提供する。

radio-calisthenics-together から抽出・汎用化。通知はコールバック注入 (on_alert)。
トークンは authorized user JSON 形式で保存する（pickle は使わない）。
"""
import os
import time
from typing import Any, Callable, Optional

from google.auth.exceptions import RefreshError, TransportError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

from .logger import setup_logger

logger = setup_logger()

TOKEN_REFRESH_MAX_RETRIES = 5
TOKEN_REFRESH_RETRY_DELAY = 30  # seconds

SCOPES = ["https://www.googleapis.com/auth/youtube.force-ssl"]

DEFAULT_CREDENTIALS_PATH = "config/youtube/client_secrets.json"
DEFAULT_TOKEN_PATH = "config/youtube/token.json"

AlertCallback = Callable[[str, str], None]


def save_token(creds: Credentials, token_path: str) -> None:
    """トークンを authorized user JSON として 0600 権限で保存する。"""
    token_dir = os.path.dirname(token_path)
    if token_dir and not os.path.exists(token_dir):
        os.makedirs(token_dir)
    fd = os.open(token_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        f.write(creds.to_json())


class YouTubeClient:
    def __init__(
        self,
        credentials_path: str = DEFAULT_CREDENTIALS_PATH,
        token_path: str = DEFAULT_TOKEN_PATH,
        on_alert: Optional[AlertCallback] = None,
    ) -> None:
        self.credentials_path = credentials_path
        self.token_path = token_path
        self.on_alert = on_alert
        self.youtube = self._get_service()

    # ----- auth -----

    def _load_cached_creds(self) -> Optional[Credentials]:
        if not os.path.exists(self.token_path):
            return None
        try:
            return Credentials.from_authorized_user_file(self.token_path, SCOPES)
        except ValueError as e:
            logger.warning(f"Token file {self.token_path} is invalid, re-auth needed: {e}")
            return None

    def _alert(self, subject: str, body: str) -> None:
        if self.on_alert is None:
            return
        try:
            self.on_alert(subject, body)
        except Exception as e:
            logger.error(f"Alert callback failed: {e}")

    def _refresh_creds_with_retry(self, creds: Credentials) -> Optional[Credentials]:
        """期限切れトークンをリトライ付きでリフレッシュする。全滅時はアラートを送り None を返す。"""
        last_error: Optional[Exception] = None
        for attempt in range(1, TOKEN_REFRESH_MAX_RETRIES + 1):
            try:
                creds.refresh(Request())
                last_error = None
                break
            except (RefreshError, TransportError) as e:
                last_error = e
                logger.warning(
                    f"Token refresh attempt {attempt}/{TOKEN_REFRESH_MAX_RETRIES} failed: {e}"
                )
                if attempt < TOKEN_REFRESH_MAX_RETRIES:
                    logger.info(f"Retrying in {TOKEN_REFRESH_RETRY_DELAY}s...")
                    time.sleep(TOKEN_REFRESH_RETRY_DELAY)

        if last_error:
            logger.error(f"Token refresh failed after {TOKEN_REFRESH_MAX_RETRIES} attempts")
            self._alert(
                "Token Refresh Failed",
                f"YouTubeトークンの自動更新に{TOKEN_REFRESH_MAX_RETRIES}回リトライしましたが失敗しました。\n\n"
                f"最後のエラー: {last_error}\n\n"
                "以下のコマンドで再認証してください:\n"
                "youtube-autopost-auth "
                f"--credentials {self.credentials_path} --token {self.token_path}",
            )
            return None

        return creds

    def _run_new_auth_flow(self) -> Credentials:
        if not os.path.exists(self.credentials_path):
            logger.error(f"Credentials file not found at {self.credentials_path}")
            raise FileNotFoundError(
                f"Please place your client_secrets.json at {self.credentials_path}"
            )
        flow = InstalledAppFlow.from_client_secrets_file(self.credentials_path, SCOPES)
        # 初回はブラウザでの認可が必要（ヘッドレス環境では先にホスト側で token を作る）
        return flow.run_local_server(port=0)

    def _save_creds(self, creds: Credentials) -> None:
        save_token(creds, self.token_path)

    def _get_service(self) -> Any:
        creds = self._load_cached_creds()
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds = self._refresh_creds_with_retry(creds)
            if not creds or not creds.valid:
                creds = self._run_new_auth_flow()
            self._save_creds(creds)
        return build("youtube", "v3", credentials=creds)

    def verify_token(self) -> tuple[bool, Optional[str]]:
        """トークンが有効か軽量 API call で確認する。Returns (成功, エラーメッセージ)。"""
        try:
            self.youtube.channels().list(part="id", mine=True).execute()
            return True, None
        except Exception as e:
            return False, str(e)

    # ----- video upload -----

    def upload_video(
        self,
        file_path: str,
        title: str,
        description: str = "",
        tags: Optional[list[str]] = None,
        category_id: str = "22",
        privacy_status: str = "private",
        chunk_size: int = 8 * 1024 * 1024,
    ) -> dict:
        """動画をアップロードする（resumable upload）。Returns API レスポンス dict。"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Video file not found: {file_path}")

        logger.info(f"Uploading video: {file_path} (title: {title}, privacy: {privacy_status})")
        body = {
            "snippet": {
                "title": title,
                "description": description,
                "tags": tags or [],
                "categoryId": category_id,
            },
            "status": {
                "privacyStatus": privacy_status,
                "selfDeclaredMadeForKids": False,
            },
        }
        media = MediaFileUpload(file_path, chunksize=chunk_size, resumable=True)
        request = self.youtube.videos().insert(part="snippet,status", body=body, media_body=media)

        response = None
        while response is None:
            status, response = request.next_chunk()
            if status:
                logger.info(f"Upload progress: {int(status.progress() * 100)}%")
        logger.info(f"Upload complete: video id {response.get('id')}")
        return response

    # ----- live broadcast -----

    def create_broadcast(
        self,
        title: str,
        description: str,
        start_time_iso: str,
        privacy_status: str = "public",
    ) -> dict:
        """YouTube Live 枠を作成する。start_time_iso は UTC (ISO 8601)。"""
        logger.info(
            f"Creating YouTube Live Broadcast: {title} at {start_time_iso} (Privacy: {privacy_status})"
        )
        body = {
            "snippet": {
                "title": title,
                "description": description,
                "scheduledStartTime": start_time_iso,
            },
            "status": {
                "privacyStatus": privacy_status,
                "selfDeclaredMadeForKids": False,
            },
            "contentDetails": {
                "enableAutoStart": True,
                "enableAutoStop": True,
                "monitorStream": {"enableMonitorStream": False},
            },
        }
        request = self.youtube.liveBroadcasts().insert(
            part="snippet,status,contentDetails", body=body
        )
        return request.execute()

    def create_stream(self, title: str) -> dict:
        logger.info(f"Creating YouTube Live Stream: {title}")
        body = {
            "snippet": {"title": title},
            "cdn": {
                "frameRate": "30fps",
                "ingestionType": "rtmp",
                "resolution": "1080p",
            },
        }
        return self.youtube.liveStreams().insert(part="snippet,cdn", body=body).execute()

    def bind_broadcast(self, broadcast_id: str, stream_id: str) -> dict:
        logger.info(f"Binding broadcast {broadcast_id} to stream {stream_id}")
        return self.youtube.liveBroadcasts().bind(
            id=broadcast_id, part="id,contentDetails", streamId=stream_id
        ).execute()

    def list_upcoming_broadcasts(self) -> list[dict]:
        response = self.youtube.liveBroadcasts().list(
            part="snippet,status", broadcastStatus="upcoming", maxResults=20
        ).execute()
        return response.get("items", [])

    def list_active_broadcasts(self) -> list[dict]:
        """現在配信中の broadcast を取得する。"""
        response = self.youtube.liveBroadcasts().list(
            part="snippet,status", broadcastStatus="active", maxResults=20
        ).execute()
        return response.get("items", [])

    def delete_broadcast(self, broadcast_id: str) -> None:
        logger.info(f"Deleting broadcast: {broadcast_id}")
        self.youtube.liveBroadcasts().delete(id=broadcast_id).execute()

    def find_broadcast_by_date(self, date_str: str) -> Optional[dict]:
        """タイトルに指定した日付が含まれる待機中の枠を探す。"""
        for item in self.list_upcoming_broadcasts():
            if date_str in item["snippet"]["title"]:
                return item
        return None

"""初回 OAuth 認証 CLI。ブラウザで認可し token を保存する。

Usage:
    youtube-autopost-auth [--credentials PATH] [--token PATH]
"""
import argparse
import os

from google_auth_oauthlib.flow import InstalledAppFlow

from .client import DEFAULT_CREDENTIALS_PATH, DEFAULT_TOKEN_PATH, SCOPES, save_token


def main() -> int:
    parser = argparse.ArgumentParser(description="Authenticate with YouTube (OAuth)")
    parser.add_argument("--credentials", default=DEFAULT_CREDENTIALS_PATH)
    parser.add_argument("--token", default=DEFAULT_TOKEN_PATH)
    args = parser.parse_args()

    if not os.path.exists(args.credentials):
        print(f"Error: {args.credentials} not found.")
        print("Google Cloud Console で OAuth クライアント (Desktop) を作成し、")
        print(f"client_secrets.json を {args.credentials} に配置してください。")
        return 1

    flow = InstalledAppFlow.from_client_secrets_file(args.credentials, SCOPES)
    print("Opening browser for Google authentication...")
    creds = flow.run_local_server(port=0)

    save_token(creds, args.token)
    print(f"Successfully authenticated! Token saved to {args.token}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import logging


def setup_logger(name: str = "youtube_autopost") -> logging.Logger:
    """コンソール出力のみのシンプルな logger。

    ファイル出力等が必要なら利用側で handler を追加する。
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if logger.handlers:
        return logger

    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    )
    logger.addHandler(handler)
    return logger

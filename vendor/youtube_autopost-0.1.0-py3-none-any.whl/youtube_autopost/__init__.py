from .client import SCOPES, YouTubeClient

__all__ = ["YouTubeClient", "SCOPES"]
